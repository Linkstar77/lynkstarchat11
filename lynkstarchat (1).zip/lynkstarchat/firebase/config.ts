
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAMj92SNrYKWT67u9CpKip24b6nPQyakt8",
  authDomain: "lynkstarchat-488e9.firebaseapp.com",
  projectId: "lynkstarchat-488e9",
  storageBucket: "lynkstarchat-488e9.firebasestorage.app",
  messagingSenderId: "434263199142",
  appId: "1:434263199142:web:cc87243fbbdbdcfd7f9367",
  measurementId: "G-EX1D96BVMD"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
