
import Layout from '@/components/Layout';
import Feed from '@/components/Feed';
import Chat from '@/components/Chat';

export default function Home() {
  return (
    <Layout>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <Feed />
        </div>
        <div>
          <Chat />
        </div>
      </div>
    </Layout>
  );
}
