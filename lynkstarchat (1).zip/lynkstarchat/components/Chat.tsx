
export default function Chat() {
  return (
    <div className="bg-gray-900 p-4 rounded-2xl shadow-md">
      <h2 className="text-xl mb-2">Chat</h2>
      <p>Chat UI will go here...</p>
    </div>
  );
}
