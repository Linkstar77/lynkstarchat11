export default function Feed() {
  return (
    <div className="bg-gray-900 p-4 rounded-2xl shadow-md">
      <h2 className="text-xl mb-2">News Feed</h2>
      <p>Posts will go here...</p>
    </div>
  );
}