export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-black text-white font-roboto p-4">
      <header className="text-3xl font-bold text-center mb-4">LynkstarChat</header>
      <main>{children}</main>
    </div>
  );
}